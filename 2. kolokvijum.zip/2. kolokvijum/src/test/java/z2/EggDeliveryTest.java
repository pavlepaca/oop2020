/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavle
 */
public class EggDeliveryTest {
    
    public EggDeliveryTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of calculatePrice method, of class EggDelivery.
     */
    @Test
    public void testCalculatePrice() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 1;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 2000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice2() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 1;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 4000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice3() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 2;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 1000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice4() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 2;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 2000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice5() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 3;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 666.66F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice6() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 3;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 133.33F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice7() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 4;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 500F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice8() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 80;
        int eggClass = 4;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 1000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice9() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 1;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 3000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice10() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 1;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 6000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice11() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 2;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 1500F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice12() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 2;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 3000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice13() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 3;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 1000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice14() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 3;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 2000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice15() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 4;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 750F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice16() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 200;
        int eggClass = 4;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 1500F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice17() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 1;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 1000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice18() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 1;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 2000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice19() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 2;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 500F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice20() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 2;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 1000F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice21() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 3;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 333.33F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice22() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 3;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 666.66F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice23() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 4;
        boolean express = false;
        EggDelivery instance = new EggDelivery();
        float expResult = 250F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testCalculatePrice24() {
        System.out.println("calculatePrice");
        int numberOfEggs = 10;
        int distance = 50;
        int eggClass = 4;
        boolean express = true;
        EggDelivery instance = new EggDelivery();
        float expResult = 500F;
        float result = instance.calculatePrice(numberOfEggs, distance, eggClass, express);
        assertEquals(expResult, result);
        
    }
    
}
