/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavle
 */
public class EggClassificationTest {
    
    public EggClassificationTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of classify method, of class EggClassification.
     */
    @Test
    public void testClassify() {
        System.out.println("classify");
        int mass = 60;
        int diameter = 3;
        boolean deformation = false;
        EggClassification instance = new EggClassification();
        int expResult = 1;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testClassify2() {
        System.out.println("classify");
        int mass = 60;
        int diameter = 1;
        boolean deformation = false;
        EggClassification instance = new EggClassification();
        int expResult = 2;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testClassify3() {
        System.out.println("classify");
        int mass = 40;
        int diameter = 3;
        boolean deformation = false;
        EggClassification instance = new EggClassification();
        int expResult = 2;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testClassify4() {
        System.out.println("classify");
        int mass = 40;
        int diameter = 1;
        boolean deformation = false;
        EggClassification instance = new EggClassification();
        int expResult = 3;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
    @Test
    public void testClassify5() {
        System.out.println("classify");
        int mass = 60;
        int diameter = 3;
        boolean deformation = true;
        EggClassification instance = new EggClassification();
        int expResult = 2;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
      @Test
    public void testClassify6() {
        System.out.println("classify");
        int mass = 60;
        int diameter = 1;
        boolean deformation = true;
        EggClassification instance = new EggClassification();
        int expResult = 3;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
      @Test
    public void testClassify7() {
        System.out.println("classify");
        int mass = 40;
        int diameter = 3;
        boolean deformation = true;
        EggClassification instance = new EggClassification();
        int expResult = 3;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
      @Test
    public void testClassify8() {
        System.out.println("classify");
        int mass = 40;
        int diameter = 1;
        boolean deformation = true;
        EggClassification instance = new EggClassification();
        int expResult = 4;
        int result = instance.classify(mass, diameter, deformation);
        assertEquals(expResult, result);
        
    }
    
}
