/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z3;

/**
 *
 * @author mlade
 */
public class Egg {
    
    private int mass;
    private int diameter;
    private boolean defects;

    public int getMass() {
        return mass;
    }

    public void setMass(int mass) {
        this.mass = mass;
    }

    public int getDiameter() {
        return diameter;
    }

    public void setDiameter(int diameter) {
        this.diameter = diameter;
    }

    public boolean isDefects() {
        return defects;
    }

    public void setDefects(boolean defects) {
        this.defects = defects;
    }

    public Egg(int mass, int diameter, boolean defects) {
        this.mass = mass;
        this.diameter = diameter;
        this.defects = defects;
    }
    
    
    
}
