/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z3;

/**
 *
 * @author mlade
 */
public class EggTesting {
    
    private OpticalTester tester;
    //private Scale scale;
    
    public void testQuality(Egg egg){
        Egg eg = new Egg(10, 20, false);
       // scale.weigh(egg);
        tester.testCircumference(eg);
        tester.testDefects(egg);
        //scale.weigh(egg);
        
    }

    public OpticalTester getTester() {
        return tester;
    }

    public void setTester(OpticalTester tester) {
        this.tester = tester;
    }

    //public Scale getScale() {
      //  return scale;
    //}

    //public void setScale(Scale scale) {
    //    this.scale = scale;
    //}

   // public EggTesting(OpticalTester tester, Scale scale) {
   //     this.tester = tester;
   //     this.scale = scale;
   // }
    
    
    
}
