var app = angular.module('myApp', []);
app.controller('MyCtrl', function ($scope) {
    var vm = this;
    vm.obj = {
        id: '',
        kol: 255,
        cena: 0
    }

    vm.add = function () {
        var el = {
            id: vm.obj.id,
            kol: 255,
            cena: vm.obj.cena
        }
        vm.jaja.push(el);
        }

    vm.brisi = function (el) {
        var lista = [];
        for (var i in vm.jaja) {
            //if (vm.jaja[i] != el) {
            if(i != 0){
                lista.push(vm.jaja[i]);
            }
        }
        vm.jaja = lista;
    }

    vm.jaja = [
        { id: 'K123', kol: 123, cena: 19000},
        { id: "ZT - 144", kol: 25, cena: 5000},
        { id: 'Cl423', kol: 2000, cena: 49000 }
    ]

    vm.izracunajProsek = function(){
        vm.suma = 0;
        for(var i in vm.jaja){
            suma += vm.jaja[i].cena;
        }
        vm.prosek = suma / vm.jaja.length;
    }
});
