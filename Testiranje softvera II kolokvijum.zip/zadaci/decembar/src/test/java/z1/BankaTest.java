/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavle
 */
public class BankaTest {
    
    public BankaTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of klasifikuj method, of class Banka.
     */
    @Test
    public void testKlasifikuj() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = true;
        boolean brak = true;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 0;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj2() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = true;
        boolean brak = false;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 1;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj3() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = false;
        boolean brak = true;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 1;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj4() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = false;
        boolean brak = false;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 2;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj5() {
        System.out.println("klasifikuj");
        int uzrast = 18;
        boolean zaposlen = true;
        boolean brak = true;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 4;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj6() {
        System.out.println("klasifikuj");
        int uzrast = 18;
        boolean zaposlen = true;
        boolean brak = false;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 4;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
    
    }
    
    @Test
    public void testKlasifikuj7() {
        System.out.println("klasifikuj");
        int uzrast = 18;
        boolean zaposlen = false;
        boolean brak = true;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 4;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj8() {
        System.out.println("klasifikuj");
        int uzrast = 18;
        boolean zaposlen = false;
        boolean brak = false;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 4;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj9() {
        System.out.println("klasifikuj");
        int uzrast = 50;
        boolean zaposlen = true;
        boolean brak = true;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 1;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj10() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = true;
        boolean brak = true;
        boolean istorija = true;
        Banka instance = new Banka();
        int expResult = 1;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj11() {
        System.out.println("klasifikuj");
        int uzrast = 50;
        boolean zaposlen = true;
        boolean brak = false;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 2;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj12() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = true;
        boolean brak = false;
        boolean istorija = true;
        Banka instance = new Banka();
        int expResult = 2;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj13() {
        System.out.println("klasifikuj");
        int uzrast = 50;
        boolean zaposlen = false;
        boolean brak = true;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 2;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj14() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = false;
        boolean brak = true;
        boolean istorija = true;
        Banka instance = new Banka();
        int expResult = 2;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj15() {
        System.out.println("klasifikuj");
        int uzrast = 50;
        boolean zaposlen = false;
        boolean brak = false;
        boolean istorija = false;
        Banka instance = new Banka();
        int expResult = 3;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testKlasifikuj16() {
        System.out.println("klasifikuj");
        int uzrast = 30;
        boolean zaposlen = false;
        boolean brak = false;
        boolean istorija = true;
        Banka instance = new Banka();
        int expResult = 3;
        int result = instance.klasifikuj(uzrast, zaposlen, brak, istorija);
        assertEquals(expResult, result);
        
    }
}
