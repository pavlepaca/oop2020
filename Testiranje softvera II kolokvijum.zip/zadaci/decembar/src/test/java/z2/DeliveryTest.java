/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavle
 */
public class DeliveryTest {
    
    public DeliveryTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of deliverPackage method, of class Delivery.
     */
    @Test
    public void testDeliverPackage() {
        System.out.println("deliverPackage");
        int masa = 40;
        int udaljenost = 10;
        boolean inostranstvo = true;
        Delivery.TipDostave tip = tip.Obicna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1030;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage2() {
        System.out.println("deliverPackage");
        int masa = 40;
        int udaljenost = 10;
        boolean inostranstvo = false;
        Delivery.TipDostave tip = tip.Obicna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 780;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage3() {
        System.out.println("deliverPackage");
        int masa = 60;
        int udaljenost = 10;
        boolean inostranstvo = false;
        Delivery.TipDostave tip = tip.Obicna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1380;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage4() {
        System.out.println("deliverPackage");
        int masa = 600;
        int udaljenost = 10;
        boolean inostranstvo = true;
        Delivery.TipDostave tip = tip.Obicna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1630;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage5() {
        System.out.println("deliverPackage");
        int masa = 40;
        int udaljenost = 10;
        boolean inostranstvo = false;
        Delivery.TipDostave tip = tip.Brza;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 880;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage6() {
        System.out.println("deliverPackage");
        int masa = 40;
        int udaljenost = 10;
        boolean inostranstvo = true;
        Delivery.TipDostave tip = tip.Brza;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1130;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage7() {
        System.out.println("deliverPackage");
        int masa = 60;
        int udaljenost = 10;
        boolean inostranstvo = false;
        Delivery.TipDostave tip = tip.Brza;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1580;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage8() {
        System.out.println("deliverPackage");
        int masa = 60;
        int udaljenost = 10;
        boolean inostranstvo = true;
        Delivery.TipDostave tip = tip.Brza;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1830;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage9() {
        System.out.println("deliverPackage");
        int masa = 40;
        int udaljenost = 10;
        boolean inostranstvo = false;
        Delivery.TipDostave tip = tip.Hitna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 980;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage10() {
        System.out.println("deliverPackage");
        int masa = 40;
        int udaljenost = 10;
        boolean inostranstvo = true;
        Delivery.TipDostave tip = tip.Hitna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1280;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage11() {
        System.out.println("deliverPackage");
        int masa = 60;
        int udaljenost = 10;
        boolean inostranstvo = false;
        Delivery.TipDostave tip = tip.Hitna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 1780;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testDeliverPackage12() {
        System.out.println("deliverPackage");
        int masa = 60;
        int udaljenost = 10;
        boolean inostranstvo = true;
        Delivery.TipDostave tip = tip.Hitna;
        int brojPredmeta = 2;
        Delivery instance = new Delivery();
        float expResult = 2030;
        float result = instance.deliverPackage(masa, udaljenost, inostranstvo, tip, brojPredmeta);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}
