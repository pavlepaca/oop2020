/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z3;

import java.util.ArrayList;

/**
 *
 * @author Mladen
 */
public class MedTehnicar {
    
    public void pregledajPacijente(ArrayList<Pacijent> p){
        for(Pacijent pac : p){
            this.pregledajJednog(pac);
        }
    }
    
    public void pregledajJednog(Pacijent p){
        
    }
    
}
