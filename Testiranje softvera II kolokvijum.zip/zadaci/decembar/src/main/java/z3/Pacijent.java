/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z3;

/**
 *
 * @author Mladen
 */
public class Pacijent {
    private String ime;
    private String prezime;
    private String sifraKartona;
    
    public Pacijent(){
    
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getSifraKartona() {
        return sifraKartona;
    }

    public void setSifraKartona(String sifraKartona) {
        this.sifraKartona = sifraKartona;
    }
    
    
}
