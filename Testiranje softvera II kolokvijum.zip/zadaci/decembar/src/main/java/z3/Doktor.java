/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package z3;

import java.util.ArrayList;

/**
 *
 * @author Mladen
 */
public class Doktor {
    
    private MedTehnicar medTehnicar;
    private Specijalista specijalista;
    
    public void pregledajPacijente(ArrayList<Pacijent> pacijenti){
        
        medTehnicar.pregledajPacijente(pacijenti);
        
        for(int i = pacijenti.size(); i>0; i--){
            this.dijagnoziraj(pacijenti.get(i-1));
            
            if(pacijenti.get(i-1).isBolestan()){
                this.otpusti(pacijenti.get(i-1));
            }
            else if(!pacijenti.get(i-1).isTezakSlucaj()){
                this.propisiLekove(pacijenti.get(i-1));
            }
            else{
                this.specijalista.pregledaj(pacijenti.get(i-1));
                this.specijalista.tretiraj(pacijenti.get(i-1));
                this.specijalista.pripremi(pacijenti.get(i-1));
            }
            
            
        }
        
        
        
    }
    
    public void dijagnoziraj(Pacijent p){
        //Not implemented yet
    }
    
    public void otpusti(Pacijent p){
        
    }
    
    public void propisiLekove(Pacijent p){
        
    }
    
    
    
}
